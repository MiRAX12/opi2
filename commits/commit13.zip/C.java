public class C implements J {

    private long b = 1234;

    private byte d = 1;

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public float ff() {
        return 0;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public void ab() {
        return;
    }

    public long ac() {
        return 111;
    }

    public int ae() {
        return 8;
    }

    public void bb() {
        System.out.println(42);
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
