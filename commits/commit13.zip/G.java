public class G implements J {

    private byte d = 1;

    private byte k = 1;

    public double ee() {
        return 500.100;
    }

    public int af() {
        return -1;
    }

    public float ff() {
        return 0;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public int cc() {
        return 13;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public Object pp() {
        return this;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public long ac() {
        return 333;
    }
}
